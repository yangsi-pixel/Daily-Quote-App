package com.example.s_quotes;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapter extends RecyclerView.Adapter<viewholder> {
    private  ArrayList qt_id;
    private Context context;
    private Activity activity;
    private ArrayList  qt_nm;
    private ArrayList  dell;
    adapter(Context context, Activity activity, ArrayList qt_id, ArrayList qt_nm){
        this.activity = activity;
        this.context = context;
        this.qt_id = qt_id;
        this.qt_nm = qt_nm;
    }
    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.items, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        holder.qt_id.setText(String.valueOf(qt_id.get(position)));
        holder.qt_nm.setText(String.valueOf(qt_nm.get(position)));
    }

    @Override
    public int getItemCount() {
        return qt_id.size();
    }
}
