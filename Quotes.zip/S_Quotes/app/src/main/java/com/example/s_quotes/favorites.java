package com.example.s_quotes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class favorites extends AppCompatActivity {
    RecyclerView recycle;
    ArrayList<String> id , quo,del;
    db_help dd;
    adapter adapt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        dd = new db_help(favorites.this);
        id = new ArrayList<>();
        quo = new ArrayList<>();
        del = new ArrayList<>();
        recycle = findViewById(R.id.rv);
        adapt = new adapter(favorites.this, favorites.this, id,quo);
        recycle.setAdapter(adapt);
        recycle.setLayoutManager(new LinearLayoutManager(favorites.this));
        displaydata();
    }
    private void displaydata()
    {
        Cursor cursor = dd.getdata();
        if(cursor.getCount()==0)
        {
            Toast.makeText(favorites.this, "No favorite quotes yet..", Toast.LENGTH_SHORT).show();
        }
        else
        {
            while(cursor.moveToNext())
            {
                id.add(cursor.getString(0));
                quo.add(cursor.getString(1));
            }
        }
    }
}