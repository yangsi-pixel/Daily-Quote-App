package com.example.s_quotes;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.ImageButton;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView tv;
   ImageView share, fav;
   Button ed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv2);
        share = findViewById(R.id.share);
        fav = findViewById(R.id.fav);
        ed = findViewById(R.id.edt);
        Random rand = new Random();
        int i = rand.nextInt(51);
        String[] motivationalTexts = new String[50];
        motivationalTexts[0] = "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle.";
        motivationalTexts[1] = "You are never too old to set another goal or to dream a new dream.";
        motivationalTexts[2] = "Success is not final, failure is not fatal: it is the courage to continue that counts.";
        motivationalTexts[3] = "The only way to do great work is to love what you do. If you haven't found it yet, keep looking.";
        motivationalTexts[4] = "Believe you can and you're halfway there.";
        motivationalTexts[5] = "The best way to predict the future is to create it.";
        motivationalTexts[6] = "The only person you are destined to become is the person you decide to be.";
        motivationalTexts[7] = "Don't watch the clock; do what it does. Keep going.";
        motivationalTexts[8] = "If you want to achieve greatness stop asking for permission.";
        motivationalTexts[9] = "Believe in yourself, take on your challenges, dig deep within yourself to conquer fears. Never let anyone bring you down. You got this.";
        motivationalTexts[10] = "Believe you can and you're halfway there. —Theodore Roosevelt";
        motivationalTexts[11] = "The only limit to our realization of tomorrow will be our doubts of today.";
        motivationalTexts[12] = "The only person you are destined to become is the person you decide to be.";
        motivationalTexts[13] = "We may encounter many defeats but we must not be defeated.";
        motivationalTexts[14] = "We generate fears while we sit. – We overcome them by action.";
        motivationalTexts[15] = "The man who has confidence in himself gains the confidence of others.";
        motivationalTexts[16] = "The only limit to our realization of tomorrow will be our doubts of today.";
        motivationalTexts[17] = "Creativity is intelligence having fun.";
        motivationalTexts[18] = "What we achieve inwardly will change outer reality.";
        motivationalTexts[19] = "DONE... is better than PERFECT !!!";
        motivationalTexts[20] = "Security is mostly a superstition. – Life is either a daring adventure or nothing at all.";
        motivationalTexts[21] = "Whether you think you can or think you can’t, you’re right.";
        motivationalTexts[22] = "Imagine your life is perfect in every aspect; What would it look like?";
        motivationalTexts[23] = "People who wonder if the glass is half empty or full miss the point.";
        motivationalTexts[24] = "If you are working on something that you really care about, you don’t have to be pushed.";
        motivationalTexts[25] = "It’s not whether you get knocked down, it’s whether you get up.";
        motivationalTexts[26] = "You learn more from failure than from success. – Don’t let it stop you.";
        motivationalTexts[27] = "Don’t let yesterday take up too much of today.";
        motivationalTexts[28] = "Believe in yourself, push your limits, experience life, conquer your goals and be happy.";
        motivationalTexts[29] = "The only way of finding the limits of the possible is by going beyond them into the impossible.";
        motivationalTexts[30] = "The only person you are destined to become is the person you decide to be.";
        motivationalTexts[31] = "I didn't fail the test, I just found 100 ways to do it wrong.";
        motivationalTexts[32] = "If opportunity doesn't knock, build a door.";
        motivationalTexts[33] = "I have learned over the years that when one's mind is made up, this diminishes fear; knowing what must be done does away with fear.";
        motivationalTexts[34] = "Too many of us are not living our dreams because we are living our fears.";
        motivationalTexts[35] = "Challenges are what make life interesting and overcoming them is what makes life meaningful.";
        motivationalTexts[36] = "You can't fall if you don't climb. But there's no joy in living your whole life on the ground.";
        motivationalTexts[37] = "Remember that not getting what you want is sometimes a wonderful stroke of luck.";
        motivationalTexts[38] = "Build your own dreams, or someone else will hire you to build theirs.";
        motivationalTexts[39] = "I would rather die of passion than of boredom.";
        motivationalTexts[40] = "Believe in yourself, take on your challenges, dig deep within yourself to conquer fears. Never let anyone bring you down. You got this.";
        motivationalTexts[41] = "Everything has beauty, but not everyone can see.";
        motivationalTexts[42] = "The best way to predict the future is to invent it.";
        motivationalTexts[43] = "What we fear doing most is usually what we most need to do.";
        motivationalTexts[44] = "Act as if what you do makes a difference. It does.";
        motivationalTexts[45] = "Do what you can, where you are, with what you have.";
        motivationalTexts[46] = "You can't use up creativity. The more you use, the more you have.";
        motivationalTexts[47] = "If you're going through hell, keep going.";
        motivationalTexts[48] = "I have not failed. I've just found 10,000 ways that won't work.";
        motivationalTexts[49] = "It does not matter how slowly you go as long as you do not stop.";
        String quote = motivationalTexts[i];
        tv.setText(quote);
        share.setOnClickListener(view -> {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, quote);
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        });
        ed.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, favorites.class);
            startActivity(intent);
        });
        fav.setOnClickListener(view -> {
            db_help myDB = new db_help(MainActivity.this);
            myDB.addtsk(tv.getText().toString().trim());
        });

    }
}