package com.example.s_quotes;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class viewholder extends RecyclerView.ViewHolder
{
    TextView qt_id, qt_nm;
    ImageView del;
    LinearLayout mainLayout;
    public viewholder(@NonNull View itemView) {
        super(itemView);
        qt_id = itemView.findViewById(R.id.ID);
        qt_nm = itemView.findViewById(R.id.qu);
        mainLayout = itemView.findViewById(R.id.main);
        del = itemView.findViewById(R.id.bin);
    }
}
